# Corperate Restructure Weather

---
![](https://puu.sh/JXFG7/2e45e2d272.png)

### Features
* Navigation Monitor **[Client]**
	* Moved weather condition to top
	* Added coloring to weather condition based on hazzard
		* Unknown			 = White
		* None 				 = Green
		* DustClouds 		 = Green
		* Rainy 			 = Yellow
		* Foggy 			 = Yellow
		* Stormy 			 = Orange
		* Flooded 			 = Orange
		* Eclipsed 			 = Red

Credits to [Jamil](https://thunderstore.io/c/lethal-company/p/Jamil/Corporate_Restructure/)