# Ship Sun Shine
This mod adds the light outside of the ship when in space for a nice view of the planet you are orbiting.