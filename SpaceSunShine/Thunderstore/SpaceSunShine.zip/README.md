# Ship Sun Shine
This mod adds the light outside of the ship when in space for a nice view of the planet you are orbiting. adds back the floodlight and ladder to space.
Works best when using [SpaceShipDoor](https://thunderstore.io/c/lethal-company/p/Wolf11221/SpaceShipDoor/).