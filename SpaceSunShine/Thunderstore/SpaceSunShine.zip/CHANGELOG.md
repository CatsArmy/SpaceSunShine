* Version 1.0.0: Initial Release
* Version 1.0.1 Updated Readme
* Version 1.0.2 Manifest file for an optinal dependency