* Version 1.0.0: Initial Release
* Version 1.0.1 Updated Readme
* Version 1.0.2 Updated manifest file for an optinal dependency
* Version 1.0.3 Updated manifest file for an optinal dependency might work now