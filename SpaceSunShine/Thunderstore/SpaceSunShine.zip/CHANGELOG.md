* Version 1.2.0 Added a flood light, readded the ladder when in space, added configs to toggle all features including reverting back to the old sun
and bug fixes
* Version 1.0.4 Changed the way i was adding the light to be identical to the one in lethal expansion
* Version 1.0.3 Updated manifest file for an optinal dependency might work now
* Version 1.0.2 Updated manifest file for an optinal dependency
* Version 1.0.1 Updated Readme
* Version 1.0.0: Initial Release